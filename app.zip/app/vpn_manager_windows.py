"""
vpn_manager_windows.py — BookingScraper Pro v48
Enterprise rebuild merging v48 architecture with v2.3 field-validated fixes.

v48 features retained:
  VPNCircuitBreaker  : Opens after N failures, auto-recovers after cooldown.
  NullVPNManager     : No-op when VPN_ENABLED=False.
  get_vpn_manager()  : Factory selecting real or null manager.

v2.3 fixes restored (field-validated):
  FIX-v2.3-A  : get_current_ip() — 30s cache with threading.Lock.
                 Prevents multiple simultaneous threads saturating external
                 IP-check services (rate-limit → "Unknown" cascade → DNS
                 instability → ERR_NAME_NOT_RESOLVED in Brave).
  FIX-v2.3-B  : verify_vpn_active() — when original_ip or current = "Unknown",
                 ASSUME VPN active (not inactive). Prevents mass reconnect loops.
  FIX-v2.3-C  : _dismiss_nordvpn_popup() — closes NordVPN GUI popup
                 "Pause automatic connection this session?" via PowerShell/WScript.
                 Without this, popup steals focus and blocks Brave window.
  FIX-v1.1-A  : interactive=False for Celery mode — no blocking input() calls.
  FIX-v1.1-B  : shell=False for all subprocess calls (security + reliability).

Platform: Windows 11 / NordVPN CLI / Celery worker (non-interactive).
"""

from __future__ import annotations

import random
import subprocess
import threading
import time
from typing import Dict, List, Optional

import requests

from app.config import get_settings

try:
    import logging
    logger = logging.getLogger(__name__)
except Exception:
    import logging as logger  # type: ignore


# ---------------------------------------------------------------------------
# Circuit Breaker
# ---------------------------------------------------------------------------

# ── Validación de países (exportada para tests) ───────────────────────────────

def _validate_country(country: str) -> str:
    """
    Valida que el nombre de país sea de la lista canónica aprobada.

    Args:
        country: Nombre del país (e.g. 'Spain', 'Germany').

    Returns:
        El mismo country si es válido.

    Raises:
        ValueError: Si el país no está en la lista aprobada o está vacío.

    Exported as a module-level function for testability (SCRAP-BUG-010).
    """
    if not country or not isinstance(country, str):
        raise ValueError(
            f"Country must be a non-empty string, got: {country!r}"
        )
    cleaned = country.strip()
    if cleaned not in _VALID_VPN_COUNTRIES:
        raise ValueError(
            f"'{cleaned}' is not in the approved VPN country list. "
            f"Valid options: {sorted(_VALID_VPN_COUNTRIES)}"
        )
    return cleaned


class VPNCircuitBreaker:
    """
    Prevents repeated VPN connect attempts after consecutive failures.
    Opens after max_failures, auto-recovers after cooldown_seconds.
    """
    def __init__(self, max_failures: int = 3, cooldown_seconds: float = 300.0) -> None:
        self._failures        = 0
        self._max_failures    = max_failures
        self._cooldown        = cooldown_seconds
        self._opened_at: Optional[float] = None
        self._lock            = threading.Lock()

    @property
    def is_open(self) -> bool:
        with self._lock:
            if self._opened_at is None:
                return False
            if time.monotonic() - self._opened_at >= self._cooldown:
                self._failures  = 0
                self._opened_at = None
                logger.info("VPN circuit breaker CLOSED (cooldown elapsed).")
                return False
            return True

    def record_success(self) -> None:
        with self._lock:
            self._failures  = 0
            self._opened_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._max_failures and self._opened_at is None:
                self._opened_at = time.monotonic()
                logger.warning("VPN circuit breaker OPENED after %d failures.", self._failures)


# ---------------------------------------------------------------------------
# NordVPN Manager — full implementation
# ---------------------------------------------------------------------------

class NordVPNManager:
    """
    Manages NordVPN rotation via NordVPN CLI on Windows 11.
    v2.3 fixes: IP cache, popup dismissal, Unknown-IP handling.
    """

    # Country code → full name (used in CLI commands)
    COUNTRY_NAMES: Dict[str, str] = {
        "US": "United States",
        "UK": "United Kingdom",
        "DE": "Germany",
        "FR": "France",
        "NL": "Netherlands",
        "ES": "Spain",
        "IT": "Italy",
        "CA": "Canada",
        "SE": "Sweden",
        "CH": "Switzerland",
    }

    # NordVPN CLI executable — Windows 11 default path
    _NORDVPN_EXE: str = r"C:\Program Files\NordVPN\nordvpn.exe"

    def __init__(self, interactive: bool = False) -> None:
        """
        Args:
            interactive: False for Celery workers (no input() prompts).
                         True for manual/console testing only.
        """
        self._cfg         = get_settings()
        self._interactive = interactive
        self._breaker     = VPNCircuitBreaker(max_failures=3, cooldown_seconds=300.0)
        self._lock        = threading.Lock()
        self._last_rotation: float = 0.0
        self._current_country: Optional[str] = None

        # FIX-v2.3-A: IP cache — prevents thread saturation of external services
        self._ip_cache_value: str   = "Unknown"
        self._ip_cache_time:  float = 0.0
        self._ip_cache_ttl:   float = 30.0
        self._ip_cache_lock   = threading.Lock()

        # Capture original IP (before any VPN connection)
        self._original_ip = self._detect_original_ip()

        # BUG-VPN-HOME-COUNTRY FIX: detect the operator real country code so we
        # can exclude it from the VPN rotation pool. Connecting to the same country
        # as the operator physical location defeats geo-bypass (Booking.com will
        # still serve local currency/pricing instead of European rates).
        # Example: user in Canada + Canada in VPN_COUNTRIES → random.choice picks CA
        # → VPN tunnel runs through Canada → CAD currency shown instead of EUR.
        self._home_country_code: Optional[str] = self._detect_home_country()

        logger.info(
            "NordVPNManager initialised | interactive=%s | original_ip=%s | home_country=%s",
            interactive, self._original_ip, self._home_country_code,
        )

    # ── Public API ────────────────────────────────────────────────────────────

    def connect(self, country: Optional[str] = None) -> bool:
        """Connect VPN to given country code (e.g. 'DE', 'UK') or random."""
        if self._breaker.is_open:
            logger.warning("VPN circuit breaker is OPEN — skipping connect.")
            return False

        cfg_countries = self._cfg.VPN_COUNTRIES
        if country is None:
            # Map country names from config to country codes
            available_codes = self._names_to_codes(cfg_countries)
            if not available_codes:
                available_codes = list(self.COUNTRY_NAMES.keys())

            # BUG-VPN-HOME-COUNTRY FIX: exclude the operator home country from
            # the random selection pool. If the user is in Canada and "Canada"
            # is in VPN_COUNTRIES, random.choice may pick CA → VPN tunnel runs
            # through Canada → Booking.com serves CAD instead of EUR.
            if self._home_country_code and self._home_country_code in available_codes:
                filtered = [c for c in available_codes if c != self._home_country_code]
                if filtered:
                    logger.info(
                        "VPN: excluding home country %s from pool — remaining: %s",
                        self._home_country_code, ",".join(filtered),
                    )
                    available_codes = filtered
                else:
                    logger.warning(
                        "VPN: home country exclusion would empty pool — keeping all countries"
                    )

            country = random.choice(available_codes)

        country_name = self.COUNTRY_NAMES.get(country, country)
        logger.info("VPN: connecting to %s (%s)...", country_name, country)

        success = self._connect_via_cli(country_name)
        if success:
            self._breaker.record_success()
            self._current_country = country
        else:
            self._breaker.record_failure()
        return success

    def disconnect(self) -> bool:
        """Disconnect VPN."""
        try:
            result = subprocess.run(
                [self._NORDVPN_EXE, "-d"],
                capture_output=True, text=True, timeout=30, shell=False,
            )
            success = result.returncode == 0 or "disconnected" in result.stdout.lower()
            if success:
                self._current_country = None
                logger.info("VPN disconnected.")
            else:
                logger.warning("VPN disconnect returned code %d: %r", result.returncode, result.stderr)
            return success
        except Exception as exc:
            logger.error("VPN disconnect failed: [%s] %s", type(exc).__name__, exc)
            return False

    def rotate(self) -> bool:
        """
        Rotate VPN to a different country.
        Avoids current country; uses circuit breaker protection.
        BUG-VPN-LOCK: re-check should_rotate() INSIDE the lock to prevent two
        threads from both rotating after the first one already updated _last_rotation.
        """
        with self._lock:
            # BUG-VPN-LOCK: another thread may have just rotated while we were waiting.
            # If interval has not elapsed yet, skip — the rotation already happened.
            elapsed = time.monotonic() - self._last_rotation
            if elapsed < self._cfg.VPN_ROTATION_INTERVAL and self._last_rotation > 0:
                logger.info(
                    "VPN: rotation skipped — another thread rotated %.0fs ago (interval=%ds).",
                    elapsed, self._cfg.VPN_ROTATION_INTERVAL,
                )
                return True  # Previous rotation counts as success

            logger.info("VPN: rotating (current=%s)...", self._current_country)
            self.disconnect()
            time.sleep(5)

            cfg_countries = self._cfg.VPN_COUNTRIES
            available = self._names_to_codes(cfg_countries) or list(self.COUNTRY_NAMES.keys())

            # Avoid current country
            if self._current_country and self._current_country in available:
                available = [c for c in available if c != self._current_country]
            if not available:
                available = list(self.COUNTRY_NAMES.keys())

            new_country = random.choice(available)
            success = self.connect(new_country)

            if success:
                self._last_rotation = time.monotonic()
                logger.info("VPN rotation successful → %s", self.COUNTRY_NAMES.get(new_country, new_country))
            else:
                logger.error("VPN rotation failed → %s", new_country)
            return success

    def should_rotate(self) -> bool:
        """True if rotation interval has elapsed since last rotation."""
        return (time.monotonic() - self._last_rotation) >= self._cfg.VPN_ROTATION_INTERVAL

    def get_status(self) -> Dict:
        """Return current VPN status dict."""
        current_ip = self.get_current_ip()
        return {
            "enabled":          self._cfg.VPN_ENABLED,
            "connected":        self.verify_vpn_active(),
            "current_country":  self._current_country,
            "current_ip":       current_ip,
            "original_ip":      self._original_ip,
            "circuit_breaker":  "open" if self._breaker.is_open else "closed",
            "rotation_interval": self._cfg.VPN_ROTATION_INTERVAL,
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    def _connect_via_cli(self, country_name: str) -> bool:
        """Execute NordVPN CLI connect command."""
        try:
            # Disconnect first
            subprocess.run(
                [self._NORDVPN_EXE, "-d"],
                capture_output=True, timeout=30, shell=False,
            )
            time.sleep(3)

            result = subprocess.run(
                [self._NORDVPN_EXE, "-c", "-g", country_name],
                capture_output=True, text=True, timeout=60, shell=False,
            )
            connected = (
                result.returncode == 0
                or "connected" in result.stdout.lower()
            )
            if connected:
                # BUG-VPN-POPUP: popup appears 1-3s AFTER CLI confirms connection.
                # First dismiss runs immediately; second runs after 2s to catch late popup.
                # FIX-v2.3-C: dismiss "Pausar la conexión automática" dialog via ESC.
                self._dismiss_nordvpn_popup()
                time.sleep(2)
                self._dismiss_nordvpn_popup()   # Second attempt for late-appearing popup
                time.sleep(8)                   # Allow VPN tunnel to fully stabilise

                # BUG-VPN-CACHE: invalidate cached IP before checking new IP.
                # Without this, the 30s cache returns the PREVIOUS VPN IP, making
                # Netherlands → Sweden look like "same IP" and logging wrong country.
                with self._ip_cache_lock:
                    self._ip_cache_time  = 0.0
                    self._ip_cache_value = "Unknown"

                new_ip = self.get_current_ip()
                if new_ip != self._original_ip and new_ip != "Unknown":
                    logger.info("VPN connected to %s — IP: %s", country_name, new_ip)
                    return True
                else:
                    logger.error("VPN CLI connected but IP unchanged (original=%s current=%s)",
                                 self._original_ip, new_ip)
                    return False
            else:
                logger.error("NordVPN connect failed: country=%s rc=%d stderr=%r stdout=%r",
                             country_name, result.returncode, result.stderr, result.stdout)
                return False

        except subprocess.TimeoutExpired:
            logger.error("NordVPN connect timed out for %s", country_name)
            return False
        except FileNotFoundError:
            logger.error(
                "NordVPN executable not found at %s. "
                "Install NordVPN or set VPN_ENABLED=false in .env.", self._NORDVPN_EXE
            )
            return False
        except Exception as exc:
            logger.error("NordVPN subprocess error: [%s] %s", type(exc).__name__, exc)
            return False

    def _dismiss_nordvpn_popup(self) -> None:
        """
        FIX-v2.3-C / BUG-VPN-POPUP:
        Close the NordVPN GUI popup: '¿Pausar la conexión automática en esta sesión?'
        Strategy:
          1. Find NordVPN window and send TAB to move focus to 'Cancelar' button, then ENTER.
          2. Fallback: send ESC (which also dismisses as 'Cancelar').
        The popup appears 1-3 seconds after the CLI confirms connection — call this
        function twice with a 2s gap for reliable dismissal.
        """
        try:
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                "$proc = Get-Process -Name 'NordVPN' -ErrorAction SilentlyContinue; "
                "if ($proc) { "
                "  $wsh = New-Object -ComObject WScript.Shell; "
                "  $activated = $wsh.AppActivate('NordVPN'); "
                "  if ($activated) { "
                "    Start-Sleep -Milliseconds 300; "
                "    [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); "
                "    Start-Sleep -Milliseconds 200; "
                "    [System.Windows.Forms.SendKeys]::SendWait('{TAB}{ENTER}'); "
                "  } "
                "}"
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
                capture_output=True, timeout=5, shell=False,
            )
        except Exception:
            pass  # Non-critical — popup TTL is short and VPN still connects

    def _detect_original_ip(self) -> str:
        """Capture IP before any VPN connection."""
        try:
            ip = self.get_current_ip()
            logger.info("VPN: original IP = %s", ip)
            return ip
        except Exception:
            logger.warning("VPN: could not detect original IP")
            return "Unknown"

    def _detect_home_country(self) -> Optional[str]:
        """
        BUG-VPN-HOME-COUNTRY FIX: Detect operator real country code via IP geolocation.
        Uses ipinfo.io (free tier, no key required for ~50k req/day).
        Returns ISO country code (e.g. 'CA', 'US') or None if detection fails.
        Called once at __init__ — result is cached in self._home_country_code.
        """
        if self._original_ip in ("Unknown", "", None):
            logger.warning("VPN: home country detection skipped — original IP unknown")
            return None
        try:
            resp = requests.get(
                f"https://ipinfo.io/{self._original_ip}/country",
                timeout=8,
            )
            if resp.status_code == 200:
                code = resp.text.strip().upper()
                if len(code) == 2 and code.isalpha():
                    logger.info("VPN: home country detected = %s", code)
                    return code
        except Exception as exc:
            logger.warning("VPN: home country detection failed: %s", exc)
        return None

    def _names_to_codes(self, country_names: List[str]) -> List[str]:
        """Convert config country names (e.g. 'Germany') to codes (e.g. 'DE')."""
        name_to_code = {v.lower(): k for k, v in self.COUNTRY_NAMES.items()}
        codes = []
        for name in country_names:
            code = name_to_code.get(name.lower())
            if code:
                codes.append(code)
            elif name.upper() in self.COUNTRY_NAMES:
                codes.append(name.upper())
        return codes

    # ── IP verification ───────────────────────────────────────────────────────

    def get_current_ip(self) -> str:
        """
        FIX-v2.3-A: Cached IP lookup (30s TTL, thread-safe).
        Prevents multiple simultaneous threads saturating external IP services.
        """
        with self._ip_cache_lock:
            now = time.time()
            if (now - self._ip_cache_time < self._ip_cache_ttl
                    and self._ip_cache_value != "Unknown"):
                return self._ip_cache_value

        # HTTP call outside lock to avoid blocking other threads
        services = [
            "https://api.ipify.org?format=text",
            "https://ifconfig.me/ip",
            "https://icanhazip.com",
            "https://ipinfo.io/ip",
            "https://checkip.amazonaws.com",
        ]
        result = "Unknown"
        for svc in services:
            try:
                resp = requests.get(svc, timeout=8)
                if resp.status_code == 200:
                    result = resp.text.strip()
                    break
            except Exception:
                continue

        with self._ip_cache_lock:
            self._ip_cache_value = result
            self._ip_cache_time  = time.time()

        if result == "Unknown":
            logger.warning("VPN: could not obtain current IP")
        return result

    def verify_vpn_active(self) -> bool:
        """
        FIX-v2.3-B: Verify IP differs from original.
        When either IP is 'Unknown', ASSUME VPN active (not inactive).
        Rationale: false positive (assume connected) is safer than false
        negative (mass reconnect attempts under DNS stress).
        """
        if not self._original_ip or self._original_ip == "Unknown":
            logger.warning("VPN: original IP unknown — assuming active")
            return True

        current = self.get_current_ip()
        if current == "Unknown":
            logger.warning("VPN: current IP unknown — assuming active (no mass reconnect)")
            return True

        if current != self._original_ip:
            logger.debug("VPN: active — IP: %s", current)
            return True

        logger.warning("VPN: inactive — IP=%s == original=%s", current, self._original_ip)
        return False

    def reconnect_if_down(self) -> bool:
        """Reconnect if VPN is no longer active."""
        if not self.verify_vpn_active():
            logger.warning("VPN dropped — reconnecting to %s", self._current_country)
            return self.connect(self._current_country)
        return True


# ---------------------------------------------------------------------------
# Null VPN Manager — used when VPN_ENABLED=False
# ---------------------------------------------------------------------------

class NullVPNManager:
    """No-op VPN manager for deployments without VPN."""
    def connect(self, country: Optional[str] = None) -> bool:
        return True
    def disconnect(self) -> bool:
        return True
    def rotate(self) -> bool:
        return True
    def should_rotate(self) -> bool:
        return False
    def verify_vpn_active(self) -> bool:
        return True
    def get_current_ip(self) -> str:
        return "N/A (VPN disabled)"
    def get_status(self) -> Dict:
        return {"enabled": False, "connected": False, "current_country": None}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

# Alias para compatibilidad con tests — CircuitBreaker es VPNCircuitBreaker
CircuitBreaker = VPNCircuitBreaker


def get_vpn_manager():
    """Return NordVPNManager or NullVPNManager based on VPN_ENABLED config."""
    cfg = get_settings()
    if cfg.VPN_ENABLED:
        return NordVPNManager(interactive=False)
    return NullVPNManager()
